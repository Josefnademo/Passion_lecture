let users = [
  {
    username: "C-H",
    password: "password123",
    isAdmin: true,
  },
  {
    username: "Piguet",
    password: "password123",
    isAdmin: true,
  },
  {
    username: "albert",
    password: "password123",
    isAdmin: false,
  },
  {
    username: "GregLeBarbar",
    password: "password123",
    isAdmin: false,
  },
  {
    username: "Yosef",
    password: "password123",
    isAdmin: true,
  },
];
export { users };
