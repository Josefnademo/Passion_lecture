let evaluations = [
  {
    commentaire: "Elle très mauvais à lire",
    note: 3,
    book_id: 1,
    user_id: 1,
  },
  {
    commentaire: "north korea forever",
    note: 5,
    book_id: 2,
    user_id: 2,
  },
  {
    commentaire: "Amazing American JOKE!",
    note: 10,
    book_id: 5,
    user_id: 1,
  },
  {
    commentaire: "tesgindssdfsdsd",
    note: 10,
    book_id: 3,
    user_id: 3,
  },
  {
    commentaire: "did not like it",
    note: 1,
    book_id: 2,
    user_id: 5,
  },
];
export { evaluations };
