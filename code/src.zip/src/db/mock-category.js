let categories = [
  {
    nom: "Policier",
  },
  {
    nom: "Fantasy",
  },
  {
    nom: "Romance",
  },
  {
    nom: "scolaire",
  },
  {
    nom: "documentaire",
  },
];

export { categories };
